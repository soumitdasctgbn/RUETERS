# PROJECT_RUETERS
Before runnig the software make sure python is installed and added to path variable.
then copy and paste the following command on cmd:
pip install pymongo
pip install PILLOW

